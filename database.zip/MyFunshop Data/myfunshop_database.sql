-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2018 at 11:47 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myfunshop_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_09_06_083208_database_initiation', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ms_bank`
--

CREATE TABLE `ms_bank` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_branch` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_brand`
--

CREATE TABLE `ms_brand` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_city`
--

CREATE TABLE `ms_city` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_province_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_courier`
--

CREATE TABLE `ms_courier` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_courier_package`
--

CREATE TABLE `ms_courier_package` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_courier_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_district`
--

CREATE TABLE `ms_district` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_city_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_prod_cat_child`
--

CREATE TABLE `ms_prod_cat_child` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_fee_percent` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_prod_cat_parent_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_prod_cat_grandparent`
--

CREATE TABLE `ms_prod_cat_grandparent` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_fee_percent` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_prod_cat_parent`
--

CREATE TABLE `ms_prod_cat_parent` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_fee_percent` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_prod_cat_grandparent_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_province`
--

CREATE TABLE `ms_province` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_variant`
--

CREATE TABLE `ms_variant` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `variant` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_variant_category`
--

CREATE TABLE `ms_variant_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `variant_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_prod_cat_child_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ms_village`
--

CREATE TABLE `ms_village` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_district_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business`
--

CREATE TABLE `st_business` (
  `id` int(10) UNSIGNED NOT NULL,
  `business_pattern` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `fax` int(11) DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequency_order_product` int(11) DEFAULT NULL,
  `product_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `annual_capital_volume` int(11) DEFAULT NULL,
  `short_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `long_description` text COLLATE utf8mb4_unicode_ci,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_village_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business_bank`
--

CREATE TABLE `st_business_bank` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_branch` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business_courier`
--

CREATE TABLE `st_business_courier` (
  `id` int(10) UNSIGNED NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_courier_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business_product`
--

CREATE TABLE `st_business_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_quantity` int(11) NOT NULL,
  `price` int(11) DEFAULT NULL,
  `stock_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_condition` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `weight_type` text COLLATE utf8mb4_unicode_ci,
  `weight` double DEFAULT NULL,
  `length` double DEFAULT NULL,
  `width` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `preorder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preorder_time` int(11) DEFAULT NULL,
  `is_refundable` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_sellable` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_variant` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_prod_cat_grandparent_id` int(10) UNSIGNED DEFAULT NULL,
  `ms_prod_cat_parent_id` int(10) UNSIGNED DEFAULT NULL,
  `ms_prod_cat_child_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_parent_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_id` int(10) UNSIGNED DEFAULT NULL,
  `ms_brand_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business_product_image`
--

CREATE TABLE `st_business_product_image` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_variant_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business_product_price`
--

CREATE TABLE `st_business_product_price` (
  `id` int(10) UNSIGNED NOT NULL,
  `min_quantity` int(11) DEFAULT NULL,
  `max_quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT NULL,
  `stock_type` int(11) DEFAULT NULL,
  `start_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_variant_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business_product_stock`
--

CREATE TABLE `st_business_product_stock` (
  `id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_variant_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_business_product_variant`
--

CREATE TABLE `st_business_product_variant` (
  `id` int(10) UNSIGNED NOT NULL,
  `price` int(11) DEFAULT NULL,
  `min_quantity` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `ms_variant_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_discussion_product`
--

CREATE TABLE `st_discussion_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `discuss` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_variant_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL,
  `st_discussion_product_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trx_cart`
--

CREATE TABLE `trx_cart` (
  `id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `notes_buyer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_variant_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trx_payment`
--

CREATE TABLE `trx_payment` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_total` int(11) NOT NULL,
  `unique_code` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ms_bank_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_bank_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL,
  `trx_transaction_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trx_review_business`
--

CREATE TABLE `trx_review_business` (
  `id` int(10) UNSIGNED NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `comment` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_id` int(10) UNSIGNED DEFAULT NULL,
  `trx_transaction_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL,
  `trx_review_business_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trx_review_product`
--

CREATE TABLE `trx_review_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_variant_id` int(10) UNSIGNED DEFAULT NULL,
  `trx_transaction_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL,
  `trx_review_product_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trx_transaction`
--

CREATE TABLE `trx_transaction` (
  `id` int(10) UNSIGNED NOT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_fee_total` int(11) NOT NULL,
  `admin_fee_total` int(11) DEFAULT NULL,
  `grand_total` int(11) NOT NULL,
  `quantity_total` int(11) NOT NULL,
  `transaction_status_buyer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_status_seller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `u_user_address_id` int(10) UNSIGNED DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trx_transaction_product`
--

CREATE TABLE `trx_transaction_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `admin_fee` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `notes_buyer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `st_business_product_id` int(10) UNSIGNED DEFAULT NULL,
  `st_business_product_variant_id` int(10) UNSIGNED DEFAULT NULL,
  `trx_transaction_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_admin_access`
--

CREATE TABLE `u_admin_access` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_admin_role`
--

CREATE TABLE `u_admin_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_admin_role_access`
--

CREATE TABLE `u_admin_role_access` (
  `id` int(10) UNSIGNED NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `u_admin_access_id` int(10) UNSIGNED DEFAULT NULL,
  `u_admin_role_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_user`
--

CREATE TABLE `u_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pre_register` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sponsor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_user_address`
--

CREATE TABLE `u_user_address` (
  `id` int(10) UNSIGNED NOT NULL,
  `address_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_priority` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` int(11) NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` int(11) DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL,
  `u_province_id` int(10) UNSIGNED DEFAULT NULL,
  `u_city_id` int(10) UNSIGNED DEFAULT NULL,
  `u_district_id` int(10) UNSIGNED DEFAULT NULL,
  `u_village_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_user_admin`
--

CREATE TABLE `u_user_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verify_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verify_phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_picture_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_user_admin_role`
--

CREATE TABLE `u_user_admin_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `u_user_admin_id` int(10) UNSIGNED DEFAULT NULL,
  `u_admin_role_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_user_bank`
--

CREATE TABLE `u_user_bank` (
  `id` int(10) UNSIGNED NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_branch` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` int(11) NOT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_user_detail`
--

CREATE TABLE `u_user_detail` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verify_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` bigint(20) NOT NULL,
  `verify_phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_picture_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `u_user_document`
--

CREATE TABLE `u_user_document` (
  `id` int(10) UNSIGNED NOT NULL,
  `document_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verify_document` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `u_user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_bank`
--
ALTER TABLE `ms_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_brand`
--
ALTER TABLE `ms_brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_city`
--
ALTER TABLE `ms_city`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ms_city_ms_province_id_foreign` (`ms_province_id`);

--
-- Indexes for table `ms_courier`
--
ALTER TABLE `ms_courier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_courier_package`
--
ALTER TABLE `ms_courier_package`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ms_courier_package_ms_courier_id_foreign` (`ms_courier_id`);

--
-- Indexes for table `ms_district`
--
ALTER TABLE `ms_district`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ms_district_ms_city_id_foreign` (`ms_city_id`);

--
-- Indexes for table `ms_prod_cat_child`
--
ALTER TABLE `ms_prod_cat_child`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ms_prod_cat_child_ms_prod_cat_parent_id_foreign` (`ms_prod_cat_parent_id`);

--
-- Indexes for table `ms_prod_cat_grandparent`
--
ALTER TABLE `ms_prod_cat_grandparent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_prod_cat_parent`
--
ALTER TABLE `ms_prod_cat_parent`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ms_prod_cat_parent_ms_prod_cat_grandparent_id_foreign` (`ms_prod_cat_grandparent_id`);

--
-- Indexes for table `ms_province`
--
ALTER TABLE `ms_province`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_variant`
--
ALTER TABLE `ms_variant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_variant_category`
--
ALTER TABLE `ms_variant_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ms_variant_category_ms_prod_cat_child_id_foreign` (`ms_prod_cat_child_id`);

--
-- Indexes for table `ms_village`
--
ALTER TABLE `ms_village`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ms_village_ms_district_id_foreign` (`ms_district_id`);

--
-- Indexes for table `st_business`
--
ALTER TABLE `st_business`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_ms_village_id_foreign` (`ms_village_id`),
  ADD KEY `st_business_u_user_id_foreign` (`u_user_id`);

--
-- Indexes for table `st_business_bank`
--
ALTER TABLE `st_business_bank`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_bank_st_business_id_foreign` (`st_business_id`);

--
-- Indexes for table `st_business_courier`
--
ALTER TABLE `st_business_courier`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_courier_ms_courier_id_foreign` (`ms_courier_id`),
  ADD KEY `st_business_courier_st_business_id_foreign` (`st_business_id`);

--
-- Indexes for table `st_business_product`
--
ALTER TABLE `st_business_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_product_ms_prod_cat_grandparent_id_foreign` (`ms_prod_cat_grandparent_id`),
  ADD KEY `st_business_product_ms_prod_cat_parent_id_foreign` (`ms_prod_cat_parent_id`),
  ADD KEY `st_business_product_ms_prod_cat_child_id_foreign` (`ms_prod_cat_child_id`),
  ADD KEY `st_business_product_st_business_product_parent_id_foreign` (`st_business_product_parent_id`),
  ADD KEY `st_business_product_st_business_id_foreign` (`st_business_id`),
  ADD KEY `st_business_product_ms_brand_id_foreign` (`ms_brand_id`);

--
-- Indexes for table `st_business_product_image`
--
ALTER TABLE `st_business_product_image`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_product_image_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `st_business_product_image_st_business_product_variant_id_foreign` (`st_business_product_variant_id`);

--
-- Indexes for table `st_business_product_price`
--
ALTER TABLE `st_business_product_price`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_product_price_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `st_business_product_price_st_business_product_variant_id_foreign` (`st_business_product_variant_id`);

--
-- Indexes for table `st_business_product_stock`
--
ALTER TABLE `st_business_product_stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_product_stock_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `st_business_product_stock_st_business_product_variant_id_foreign` (`st_business_product_variant_id`);

--
-- Indexes for table `st_business_product_variant`
--
ALTER TABLE `st_business_product_variant`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_business_product_variant_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `st_business_product_variant_ms_variant_id_foreign` (`ms_variant_id`);

--
-- Indexes for table `st_discussion_product`
--
ALTER TABLE `st_discussion_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `st_discussion_product_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `st_discussion_product_st_business_product_variant_id_foreign` (`st_business_product_variant_id`),
  ADD KEY `st_discussion_product_u_user_id_foreign` (`u_user_id`),
  ADD KEY `st_discussion_product_st_discussion_product_id_foreign` (`st_discussion_product_id`);

--
-- Indexes for table `trx_cart`
--
ALTER TABLE `trx_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trx_cart_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `trx_cart_st_business_product_variant_id_foreign` (`st_business_product_variant_id`),
  ADD KEY `trx_cart_u_user_id_foreign` (`u_user_id`);

--
-- Indexes for table `trx_payment`
--
ALTER TABLE `trx_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trx_payment_ms_bank_id_foreign` (`ms_bank_id`),
  ADD KEY `trx_payment_u_user_bank_id_foreign` (`u_user_bank_id`),
  ADD KEY `trx_payment_u_user_id_foreign` (`u_user_id`),
  ADD KEY `trx_payment_trx_transaction_id_foreign` (`trx_transaction_id`);

--
-- Indexes for table `trx_review_business`
--
ALTER TABLE `trx_review_business`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trx_review_business_st_business_id_foreign` (`st_business_id`),
  ADD KEY `trx_review_business_trx_transaction_id_foreign` (`trx_transaction_id`),
  ADD KEY `trx_review_business_u_user_id_foreign` (`u_user_id`),
  ADD KEY `trx_review_business_trx_review_business_id_foreign` (`trx_review_business_id`);

--
-- Indexes for table `trx_review_product`
--
ALTER TABLE `trx_review_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trx_review_product_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `trx_review_product_st_business_product_variant_id_foreign` (`st_business_product_variant_id`),
  ADD KEY `trx_review_product_trx_transaction_id_foreign` (`trx_transaction_id`),
  ADD KEY `trx_review_product_u_user_id_foreign` (`u_user_id`),
  ADD KEY `trx_review_product_trx_review_product_id_foreign` (`trx_review_product_id`);

--
-- Indexes for table `trx_transaction`
--
ALTER TABLE `trx_transaction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trx_transaction_u_user_address_id_foreign` (`u_user_address_id`),
  ADD KEY `trx_transaction_u_user_id_foreign` (`u_user_id`);

--
-- Indexes for table `trx_transaction_product`
--
ALTER TABLE `trx_transaction_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trx_transaction_product_st_business_product_id_foreign` (`st_business_product_id`),
  ADD KEY `trx_transaction_product_st_business_product_variant_id_foreign` (`st_business_product_variant_id`),
  ADD KEY `trx_transaction_product_trx_transaction_id_foreign` (`trx_transaction_id`);

--
-- Indexes for table `u_admin_access`
--
ALTER TABLE `u_admin_access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_admin_role`
--
ALTER TABLE `u_admin_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_admin_role_access`
--
ALTER TABLE `u_admin_role_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_admin_role_access_u_admin_access_id_foreign` (`u_admin_access_id`),
  ADD KEY `u_admin_role_access_u_admin_role_id_foreign` (`u_admin_role_id`);

--
-- Indexes for table `u_user`
--
ALTER TABLE `u_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_user_address`
--
ALTER TABLE `u_user_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_user_address_u_user_id_foreign` (`u_user_id`),
  ADD KEY `u_user_address_u_province_id_foreign` (`u_province_id`),
  ADD KEY `u_user_address_u_city_id_foreign` (`u_city_id`),
  ADD KEY `u_user_address_u_district_id_foreign` (`u_district_id`),
  ADD KEY `u_user_address_u_village_id_foreign` (`u_village_id`);

--
-- Indexes for table `u_user_admin`
--
ALTER TABLE `u_user_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_user_admin_role`
--
ALTER TABLE `u_user_admin_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_user_admin_role_u_user_admin_id_foreign` (`u_user_admin_id`),
  ADD KEY `u_user_admin_role_u_admin_role_id_foreign` (`u_admin_role_id`);

--
-- Indexes for table `u_user_bank`
--
ALTER TABLE `u_user_bank`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_user_bank_u_user_id_foreign` (`u_user_id`);

--
-- Indexes for table `u_user_detail`
--
ALTER TABLE `u_user_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_user_detail_u_user_id_foreign` (`u_user_id`);

--
-- Indexes for table `u_user_document`
--
ALTER TABLE `u_user_document`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_user_document_u_user_id_foreign` (`u_user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ms_bank`
--
ALTER TABLE `ms_bank`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_brand`
--
ALTER TABLE `ms_brand`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_city`
--
ALTER TABLE `ms_city`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_courier`
--
ALTER TABLE `ms_courier`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_courier_package`
--
ALTER TABLE `ms_courier_package`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_district`
--
ALTER TABLE `ms_district`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_prod_cat_child`
--
ALTER TABLE `ms_prod_cat_child`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_prod_cat_grandparent`
--
ALTER TABLE `ms_prod_cat_grandparent`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_prod_cat_parent`
--
ALTER TABLE `ms_prod_cat_parent`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_province`
--
ALTER TABLE `ms_province`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_variant`
--
ALTER TABLE `ms_variant`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_variant_category`
--
ALTER TABLE `ms_variant_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ms_village`
--
ALTER TABLE `ms_village`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business`
--
ALTER TABLE `st_business`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business_bank`
--
ALTER TABLE `st_business_bank`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business_courier`
--
ALTER TABLE `st_business_courier`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business_product`
--
ALTER TABLE `st_business_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business_product_image`
--
ALTER TABLE `st_business_product_image`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business_product_price`
--
ALTER TABLE `st_business_product_price`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business_product_stock`
--
ALTER TABLE `st_business_product_stock`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_business_product_variant`
--
ALTER TABLE `st_business_product_variant`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `st_discussion_product`
--
ALTER TABLE `st_discussion_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trx_cart`
--
ALTER TABLE `trx_cart`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trx_payment`
--
ALTER TABLE `trx_payment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trx_review_business`
--
ALTER TABLE `trx_review_business`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trx_review_product`
--
ALTER TABLE `trx_review_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trx_transaction`
--
ALTER TABLE `trx_transaction`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trx_transaction_product`
--
ALTER TABLE `trx_transaction_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_admin_access`
--
ALTER TABLE `u_admin_access`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_admin_role`
--
ALTER TABLE `u_admin_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_admin_role_access`
--
ALTER TABLE `u_admin_role_access`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_user`
--
ALTER TABLE `u_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_user_address`
--
ALTER TABLE `u_user_address`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_user_admin`
--
ALTER TABLE `u_user_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_user_admin_role`
--
ALTER TABLE `u_user_admin_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_user_bank`
--
ALTER TABLE `u_user_bank`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_user_detail`
--
ALTER TABLE `u_user_detail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `u_user_document`
--
ALTER TABLE `u_user_document`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `ms_city`
--
ALTER TABLE `ms_city`
  ADD CONSTRAINT `ms_city_ms_province_id_foreign` FOREIGN KEY (`ms_province_id`) REFERENCES `ms_province` (`id`);

--
-- Constraints for table `ms_courier_package`
--
ALTER TABLE `ms_courier_package`
  ADD CONSTRAINT `ms_courier_package_ms_courier_id_foreign` FOREIGN KEY (`ms_courier_id`) REFERENCES `ms_courier` (`id`);

--
-- Constraints for table `ms_district`
--
ALTER TABLE `ms_district`
  ADD CONSTRAINT `ms_district_ms_city_id_foreign` FOREIGN KEY (`ms_city_id`) REFERENCES `ms_city` (`id`);

--
-- Constraints for table `ms_prod_cat_child`
--
ALTER TABLE `ms_prod_cat_child`
  ADD CONSTRAINT `ms_prod_cat_child_ms_prod_cat_parent_id_foreign` FOREIGN KEY (`ms_prod_cat_parent_id`) REFERENCES `ms_prod_cat_parent` (`id`);

--
-- Constraints for table `ms_prod_cat_parent`
--
ALTER TABLE `ms_prod_cat_parent`
  ADD CONSTRAINT `ms_prod_cat_parent_ms_prod_cat_grandparent_id_foreign` FOREIGN KEY (`ms_prod_cat_grandparent_id`) REFERENCES `ms_prod_cat_grandparent` (`id`);

--
-- Constraints for table `ms_variant_category`
--
ALTER TABLE `ms_variant_category`
  ADD CONSTRAINT `ms_variant_category_ms_prod_cat_child_id_foreign` FOREIGN KEY (`ms_prod_cat_child_id`) REFERENCES `ms_prod_cat_child` (`id`);

--
-- Constraints for table `ms_village`
--
ALTER TABLE `ms_village`
  ADD CONSTRAINT `ms_village_ms_district_id_foreign` FOREIGN KEY (`ms_district_id`) REFERENCES `ms_district` (`id`);

--
-- Constraints for table `st_business`
--
ALTER TABLE `st_business`
  ADD CONSTRAINT `st_business_ms_village_id_foreign` FOREIGN KEY (`ms_village_id`) REFERENCES `ms_village` (`id`),
  ADD CONSTRAINT `st_business_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `st_business_bank`
--
ALTER TABLE `st_business_bank`
  ADD CONSTRAINT `st_business_bank_st_business_id_foreign` FOREIGN KEY (`st_business_id`) REFERENCES `st_business` (`id`);

--
-- Constraints for table `st_business_courier`
--
ALTER TABLE `st_business_courier`
  ADD CONSTRAINT `st_business_courier_ms_courier_id_foreign` FOREIGN KEY (`ms_courier_id`) REFERENCES `ms_courier` (`id`),
  ADD CONSTRAINT `st_business_courier_st_business_id_foreign` FOREIGN KEY (`st_business_id`) REFERENCES `st_business` (`id`);

--
-- Constraints for table `st_business_product`
--
ALTER TABLE `st_business_product`
  ADD CONSTRAINT `st_business_product_ms_brand_id_foreign` FOREIGN KEY (`ms_brand_id`) REFERENCES `ms_brand` (`id`),
  ADD CONSTRAINT `st_business_product_ms_prod_cat_child_id_foreign` FOREIGN KEY (`ms_prod_cat_child_id`) REFERENCES `ms_prod_cat_child` (`id`),
  ADD CONSTRAINT `st_business_product_ms_prod_cat_grandparent_id_foreign` FOREIGN KEY (`ms_prod_cat_grandparent_id`) REFERENCES `ms_prod_cat_grandparent` (`id`),
  ADD CONSTRAINT `st_business_product_ms_prod_cat_parent_id_foreign` FOREIGN KEY (`ms_prod_cat_parent_id`) REFERENCES `ms_prod_cat_parent` (`id`),
  ADD CONSTRAINT `st_business_product_st_business_id_foreign` FOREIGN KEY (`st_business_id`) REFERENCES `st_business` (`id`),
  ADD CONSTRAINT `st_business_product_st_business_product_parent_id_foreign` FOREIGN KEY (`st_business_product_parent_id`) REFERENCES `st_business_product` (`id`);

--
-- Constraints for table `st_business_product_image`
--
ALTER TABLE `st_business_product_image`
  ADD CONSTRAINT `st_business_product_image_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`),
  ADD CONSTRAINT `st_business_product_image_st_business_product_variant_id_foreign` FOREIGN KEY (`st_business_product_variant_id`) REFERENCES `st_business_product_variant` (`id`);

--
-- Constraints for table `st_business_product_price`
--
ALTER TABLE `st_business_product_price`
  ADD CONSTRAINT `st_business_product_price_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`),
  ADD CONSTRAINT `st_business_product_price_st_business_product_variant_id_foreign` FOREIGN KEY (`st_business_product_variant_id`) REFERENCES `st_business_product_variant` (`id`);

--
-- Constraints for table `st_business_product_stock`
--
ALTER TABLE `st_business_product_stock`
  ADD CONSTRAINT `st_business_product_stock_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`),
  ADD CONSTRAINT `st_business_product_stock_st_business_product_variant_id_foreign` FOREIGN KEY (`st_business_product_variant_id`) REFERENCES `st_business_product_variant` (`id`);

--
-- Constraints for table `st_business_product_variant`
--
ALTER TABLE `st_business_product_variant`
  ADD CONSTRAINT `st_business_product_variant_ms_variant_id_foreign` FOREIGN KEY (`ms_variant_id`) REFERENCES `ms_variant` (`id`),
  ADD CONSTRAINT `st_business_product_variant_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`);

--
-- Constraints for table `st_discussion_product`
--
ALTER TABLE `st_discussion_product`
  ADD CONSTRAINT `st_discussion_product_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`),
  ADD CONSTRAINT `st_discussion_product_st_business_product_variant_id_foreign` FOREIGN KEY (`st_business_product_variant_id`) REFERENCES `st_business_product_variant` (`id`),
  ADD CONSTRAINT `st_discussion_product_st_discussion_product_id_foreign` FOREIGN KEY (`st_discussion_product_id`) REFERENCES `st_discussion_product` (`id`),
  ADD CONSTRAINT `st_discussion_product_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `trx_cart`
--
ALTER TABLE `trx_cart`
  ADD CONSTRAINT `trx_cart_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`),
  ADD CONSTRAINT `trx_cart_st_business_product_variant_id_foreign` FOREIGN KEY (`st_business_product_variant_id`) REFERENCES `st_business_product_variant` (`id`),
  ADD CONSTRAINT `trx_cart_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `trx_payment`
--
ALTER TABLE `trx_payment`
  ADD CONSTRAINT `trx_payment_ms_bank_id_foreign` FOREIGN KEY (`ms_bank_id`) REFERENCES `ms_bank` (`id`),
  ADD CONSTRAINT `trx_payment_trx_transaction_id_foreign` FOREIGN KEY (`trx_transaction_id`) REFERENCES `trx_transaction` (`id`),
  ADD CONSTRAINT `trx_payment_u_user_bank_id_foreign` FOREIGN KEY (`u_user_bank_id`) REFERENCES `u_user_bank` (`id`),
  ADD CONSTRAINT `trx_payment_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `trx_review_business`
--
ALTER TABLE `trx_review_business`
  ADD CONSTRAINT `trx_review_business_st_business_id_foreign` FOREIGN KEY (`st_business_id`) REFERENCES `st_business` (`id`),
  ADD CONSTRAINT `trx_review_business_trx_review_business_id_foreign` FOREIGN KEY (`trx_review_business_id`) REFERENCES `trx_review_business` (`id`),
  ADD CONSTRAINT `trx_review_business_trx_transaction_id_foreign` FOREIGN KEY (`trx_transaction_id`) REFERENCES `trx_transaction` (`id`),
  ADD CONSTRAINT `trx_review_business_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `trx_review_product`
--
ALTER TABLE `trx_review_product`
  ADD CONSTRAINT `trx_review_product_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`),
  ADD CONSTRAINT `trx_review_product_st_business_product_variant_id_foreign` FOREIGN KEY (`st_business_product_variant_id`) REFERENCES `st_business_product_variant` (`id`),
  ADD CONSTRAINT `trx_review_product_trx_review_product_id_foreign` FOREIGN KEY (`trx_review_product_id`) REFERENCES `trx_review_product` (`id`),
  ADD CONSTRAINT `trx_review_product_trx_transaction_id_foreign` FOREIGN KEY (`trx_transaction_id`) REFERENCES `trx_transaction` (`id`),
  ADD CONSTRAINT `trx_review_product_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `trx_transaction`
--
ALTER TABLE `trx_transaction`
  ADD CONSTRAINT `trx_transaction_u_user_address_id_foreign` FOREIGN KEY (`u_user_address_id`) REFERENCES `u_user_address` (`id`),
  ADD CONSTRAINT `trx_transaction_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `trx_transaction_product`
--
ALTER TABLE `trx_transaction_product`
  ADD CONSTRAINT `trx_transaction_product_st_business_product_id_foreign` FOREIGN KEY (`st_business_product_id`) REFERENCES `st_business_product` (`id`),
  ADD CONSTRAINT `trx_transaction_product_st_business_product_variant_id_foreign` FOREIGN KEY (`st_business_product_variant_id`) REFERENCES `st_business_product_variant` (`id`),
  ADD CONSTRAINT `trx_transaction_product_trx_transaction_id_foreign` FOREIGN KEY (`trx_transaction_id`) REFERENCES `trx_transaction` (`id`);

--
-- Constraints for table `u_admin_role_access`
--
ALTER TABLE `u_admin_role_access`
  ADD CONSTRAINT `u_admin_role_access_u_admin_access_id_foreign` FOREIGN KEY (`u_admin_access_id`) REFERENCES `u_admin_access` (`id`),
  ADD CONSTRAINT `u_admin_role_access_u_admin_role_id_foreign` FOREIGN KEY (`u_admin_role_id`) REFERENCES `u_admin_role` (`id`);

--
-- Constraints for table `u_user_address`
--
ALTER TABLE `u_user_address`
  ADD CONSTRAINT `u_user_address_u_city_id_foreign` FOREIGN KEY (`u_city_id`) REFERENCES `ms_city` (`id`),
  ADD CONSTRAINT `u_user_address_u_district_id_foreign` FOREIGN KEY (`u_district_id`) REFERENCES `ms_district` (`id`),
  ADD CONSTRAINT `u_user_address_u_province_id_foreign` FOREIGN KEY (`u_province_id`) REFERENCES `ms_province` (`id`),
  ADD CONSTRAINT `u_user_address_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`),
  ADD CONSTRAINT `u_user_address_u_village_id_foreign` FOREIGN KEY (`u_village_id`) REFERENCES `ms_village` (`id`);

--
-- Constraints for table `u_user_admin_role`
--
ALTER TABLE `u_user_admin_role`
  ADD CONSTRAINT `u_user_admin_role_u_admin_role_id_foreign` FOREIGN KEY (`u_admin_role_id`) REFERENCES `u_admin_role` (`id`),
  ADD CONSTRAINT `u_user_admin_role_u_user_admin_id_foreign` FOREIGN KEY (`u_user_admin_id`) REFERENCES `u_user_admin` (`id`);

--
-- Constraints for table `u_user_bank`
--
ALTER TABLE `u_user_bank`
  ADD CONSTRAINT `u_user_bank_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `u_user_detail`
--
ALTER TABLE `u_user_detail`
  ADD CONSTRAINT `u_user_detail_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);

--
-- Constraints for table `u_user_document`
--
ALTER TABLE `u_user_document`
  ADD CONSTRAINT `u_user_document_u_user_id_foreign` FOREIGN KEY (`u_user_id`) REFERENCES `u_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
