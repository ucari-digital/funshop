-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2018 at 07:41 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fsn_marketplace`
--

-- --------------------------------------------------------

--
-- Table structure for table `ms_province`
--

-- CREATE TABLE `ms_province` (
--   `id` int(10) UNSIGNED NOT NULL,
--   `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
--   `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
--   `active_flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
--   `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
--   `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
--   `created_at` timestamp NULL DEFAULT NULL,
--   `updated_at` timestamp NULL DEFAULT NULL
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ms_province`
--

INSERT INTO `ms_province` (`id`, `name`, `description`, `active_flag`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(11, 'Aceh', 'Provinsi Nanggro Aceh Darussalam', 'active', 'database_initiation_system', NULL, NULL, '2018-10-11 21:00:02'),
(12, 'Sumatera Utara', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(13, 'Sumatera Barat', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(14, 'Riau', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(15, 'Jambi', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(16, 'Sumatera Selatan', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(17, 'Bengkulu', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(18, 'Lampung', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(19, 'Kepulauan Bangka Belitung', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(21, 'Kepulauan Riau', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(31, 'Dki Jakarta', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(32, 'Jawa Barat', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(33, 'Jawa Tengah', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(34, 'Di Yogyakarta', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(35, 'Jawa Timur', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(36, 'Banten', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(51, 'Bali', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(52, 'Nusa Tenggara Barat', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(53, 'Nusa Tenggara Timur', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(61, 'Kalimantan Barat', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(62, 'Kalimantan Tengah', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(63, 'Kalimantan Selatan', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(64, 'Kalimantan Timur', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(65, 'Kalimantan Utara', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(71, 'Sulawesi Utara', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(72, 'Sulawesi Tengah', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(73, 'Sulawesi Selatan', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(74, 'Sulawesi Tenggara', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(75, 'Gorontalo', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(76, 'Sulawesi Barat', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(81, 'Maluku', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(82, 'Maluku Utara', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(91, 'Papua Barat', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(94, 'Papua', '', 'active', 'database_initiation_system', NULL, NULL, NULL),
(95, 'test', 'For test adding new province system', 'inactive', 'ADMIN', NULL, '2018-10-11 21:03:05', '2018-10-11 21:05:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ms_province`
--
-- ALTER TABLE `ms_province`
--   ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ms_province`
--
-- ALTER TABLE `ms_province`
--   MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
